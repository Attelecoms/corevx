@extends('layouts.app')

@section('content')
    <section class="content-header">
        <h1>
            @include('flash::message')
        </h1>
    </section>
    <div class="content">
        <div class="box box-primary">
            <div class="box-body">
                <div class="row" style="padding-left: 20px">
                    @if (session('alert'))
                        <div class="alert alert-success">
                            {{ session('alert') }}
                        </div>
                    @endif

                        <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">PlayList</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">Download pdf Module</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">View Comments</a>
                            </li>
{{--                            <li class="nav-item">--}}
{{--                                <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">Submit Assigments</a>--}}
{{--                            </li>--}}
                        </ul>

                        <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                                @foreach ($verifycouselinks as $verifycouselink)
                                    <iframe width="560" height="315" src="{{$verifycouselink->playlist_url}}" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

                                @endforeach
                            </div>
                            <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">  @include('items.table-course')</div>
                            <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
                                <h1 class="fa-pull-left" style="margin-left: 30px;">
                                    <a class="btn btn-success pull-right" style="margin-top: -10px;margin-bottom: 5px" href="{{ route('comments.create') }}">Add Comment</a>
                                </h1>
                                @include('comments.table-course-comments')</div>
                        </div>



                </div>
            </div>
        </div>
    </div>
@endsection
