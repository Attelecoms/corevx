@component('mail::message')

      {{ $email }}.
      <br>
Is requesting to be a teacher or an Instructor.
<br>



Thanks,<br>
AT_academy
@endcomponent
