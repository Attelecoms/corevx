<script type='text/javascript' src='{{ asset('js/jquery.js') }}'></script>
<script type='text/javascript' src='{{ asset('js/swiper.min.js') }}'></script>
<script type='text/javascript' src='{{ asset('js/masonry.pkgd.min.js') }}'></script>
<script type='text/javascript' src='{{ asset('js/jquery.collapsible.min.js') }}'></script>
<script type='text/javascript' src='{{ asset('js/custom.js') }}'></script>



<script src="bundles/latejsca38?v=2.34.2"></script>

<script src="{{asset('bundles/latejs2ca38?v=2.34.2')}}"></script>
