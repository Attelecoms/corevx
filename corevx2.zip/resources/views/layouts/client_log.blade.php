
<div class="clients-logo">
    <div class="container">
        <div class="row">
            <div class="col-12 flex flex-wrap justify-content-center justify-content-lg-between align-items-center">
                <div class="logo-wrap">
                    <img src="{{ asset('log/cisco.png') }}" alt="" width="100px"height="80px">
                </div><!-- .logo-wrap -->

                <div class="logo-wrap">
                    <img src="{{ asset('log/cisa.png') }}" alt="" width="70px"height="60px">
                </div><!-- .logo-wrap -->

                <div class="logo-wrap">
                    <img src="{{ asset('log/crisc.png') }}" alt="" width="70px"height="60px">
                </div><!-- .logo-wrap -->

                <div class="logo-wrap">
                    <img src="{{ asset('log/cpte.png') }}" alt="" width="70px"height="60px">
                </div><!-- .logo-wrap -->

                <div class="logo-wrap">
                    <img src="{{ asset('log/cism.png') }}" alt="" width="70px"height="70px">
                </div><!-- .logo-wrap -->
                <div class="logo-wrap">
                    <img src="{{ asset('log/ceh.png') }}" alt="" width="100px"height="90px">
                </div><!-- .logo-wrap -->
            </div><!-- .col -->
        </div><!-- .row -->
    </div><!-- .container -->
</div><!-- .clients-logo -->
